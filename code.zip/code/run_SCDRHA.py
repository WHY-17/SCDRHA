#Import packages
#Base packages
import h5py
import numpy as np
import pandas as pd
import sklearn
from sklearn import metrics
import tensorflow as tf

#Remove warnings
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

#scGAE modules
from Graph_autoencoder import graph_autoencoder
from preprocessing import *
from utils import *
from losses import *
from clustering import *
from sklearn.cluster import KMeans


#Load data
count = np.load('mouse_ES_cell_pca_2000.npy')
f = h5py.File('mosue_ES_cell.h5')
idents = np.array(f['Y']).reshape(-1)

#Build model
adj, adj_n = get_adj(count)
model = graph_autoencoder(count, adj=adj, adj_n=adj_n)

#Pre-training
model.pre_train(epochs = 120)


#Genertate latent embedding and visualization
Y = model.embedding(count, adj_n)

#For data with cluster structure, do the following steps for clustering-training
#Initialize cluster centers by Louvain clustering
from clustering import louvain
cl_model = louvain(level=0.5)
cl_model.update(Y, adj_mat=adj)
labels = cl_model.labels
centers = computeCentroids(Y, labels)

#Clustering training
model.alt_train(epochs=40,centers=centers)
#Genertate latent embedding and visualization after clustering4-training
Ynew = model.embedding(count, adj_n)

kmeans = KMeans(n_clusters=4)
y_pred = kmeans.fit_predict(Ynew)
nmi = np.round(metrics.normalized_mutual_info_score(idents, y_pred), 5)
ari = np.round(metrics.adjusted_rand_score(idents, y_pred), 5)
sil = metrics.silhouette_score(Ynew, idents)
print(nmi)
print(ari)
print(sil)
