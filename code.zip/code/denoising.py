# denoising.py, python 3.6.
import numpy as np
import h5py
import scanpy as sc
import anndata
from dca.api import dca
from preprocess import read_dataset, normalize


def Denosing(data):
    x = np.array(data['X'])
    y = np.array(data['Y'])
    adata = anndata.AnnData(x)
    adata.obs['Group'] = y
    adata = read_dataset(adata,
                     transpose=False,
                     test_split=False,
                     copy=True)

    sc.pp.filter_genes(adata, min_counts=1)
    dca(adata,threads=1)
    sc.pp.normalize_per_cell(adata)
    sc.pp.log1p(adata)
    sc.pp.pca(adata,n_comps=2000)
    X = adata.obsm['X_pca']
    return X, y




if __name__ == "__main__":
    data = h5py.File('mouse_ES_cell.h5', 'r')
    X, y = Denosing(data)
    np.save('mouse_ES_cell_pca_2000.npy', X)
